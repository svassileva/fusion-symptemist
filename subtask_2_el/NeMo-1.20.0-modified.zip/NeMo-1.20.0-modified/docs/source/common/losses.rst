Losses
------
.. autoclass:: nemo.collections.common.losses.AggregatorLoss
    :special-members: __init__

.. autoclass:: nemo.collections.common.losses.CrossEntropyLoss
    :special-members: __init__

.. autoclass:: nemo.collections.common.losses.MSELoss
    :special-members: __init__

.. autoclass:: nemo.collections.common.losses.SmoothedCrossEntropyLoss
    :special-members: __init__

.. autoclass:: nemo.collections.common.losses.SpanningLoss
    :special-members: __init__
