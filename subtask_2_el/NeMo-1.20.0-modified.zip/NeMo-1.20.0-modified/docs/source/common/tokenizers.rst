Tokenizers
----------
.. autoclass:: nemo.collections.common.tokenizers.AutoTokenizer
    :special-members: __init__
.. autoclass:: nemo.collections.common.tokenizers.SentencePieceTokenizer
    :special-members: __init__
.. autoclass:: nemo.collections.common.tokenizers.TokenizerSpec
    :special-members: __init__
