NeMo Speech Intent Classification and Slot Filling collection API
=================================================================


Model Classes
-------------
.. autoclass:: nemo.collections.asr.models.SLUIntentSlotBPEModel
    :show-inheritance:
    :members: 


Mixins
------

.. autoclass:: nemo.collections.asr.parts.mixins.ASRModuleMixin
    :show-inheritance:
    :members:

.. autoclass:: nemo.collections.asr.parts.mixins.ASRBPEMixin
    :show-inheritance:
    :members:

