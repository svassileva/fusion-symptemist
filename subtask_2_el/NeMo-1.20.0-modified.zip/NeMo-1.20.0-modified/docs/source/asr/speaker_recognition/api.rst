NeMo Speaker Recognition API
=============================


Model Classes
-------------
.. autoclass:: nemo.collections.asr.models.label_models.EncDecSpeakerLabelModel
    :show-inheritance:
    :members: setup_finetune_model, get_embedding, verify_speakers


